package com.t2.trabalho2.turma;

public enum Periodo {
    Periodo1,
    Periodo2
};
